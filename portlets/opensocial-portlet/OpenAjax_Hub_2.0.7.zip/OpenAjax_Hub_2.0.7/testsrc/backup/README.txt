Older tests that haven't been updated and aren't currently used.

smash
-----
    This directory used to reside at hub20/trunk/containers/test/smash.  These
tests are for the FIM implementation, but haven't been updated to the newer
Hub 2.0 API.